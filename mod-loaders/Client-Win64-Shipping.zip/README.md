<h1 align="center">Wuthering Waves Model Importer</h1>

<h4 align="center">Custom 3d models loader for Wuthering Waves</h4>

<p align="center">
  <a href="#disclaimers">Disclaimers</a> •
  <a href="#features">Features</a> •
  <a href="#wwmi-installation">WWMI Installation</a> •
  <a href="#known-issues">Known Issues</a> •
  <a href="#mod-installation">Mod Installation</a> • 
  <a href="#mod-hot-load">Mod Hot Load</a> • 
  <a href="#mod-user-hotkeys">Mod User Hotkeys</a> • 
  <a href="#mod-development">Mod Development</a> • 
  <a href="#mod-developer-hotkeys">Mod Developer Hotkeys</a> • 
  <a href="#resources">Resources</a> •
  <a href="#license">License</a>
</p>

## Disclaimers  

- **Beta Warning** — WWMI is considered stable and undergoes pre-release polishment.

## Features

- **Plug-and-Play** — Fully automated installation and game configuration via **[XXMI Launcher](https://github.com/SpectrumQT/XXMI-Launcher)**
- **Highly Optimized** — Built with minimization of performance footprint in mind
- **Cross-Platform** — Works with NVidia, AMD and Intel GPUs
- **Modder Friendly** — Enables fully automatic model re-import mod creation with **[WWMI Tools](https://github.com/SpectrumQT/WWMI-Tools)**
- **No Vertex Limit** — Removes all limitations caused by component layout of original models
- **Shape Keys Support** — Handles original shape keys overrides and enables creation of custom ones
- **Bone Merging** — Dynamically merges skeleton data to allow modders work with unified VG list

## WWMI Installation

1. Download the [latest release](https://github.com/SpectrumQT/XXMI-Launcher/releases/latest) of **XXMI-Launcher-Installer-Online-vX.X.X.msi**
2. Run **XXMI-Launcher-Installer-Online-vX.X.X.msi** with Double-Click.
3. Click **[Quick Installation]** to install **XXMI Launcher** to the default location (`%AppData%\XXMI Launcher`) or use **[Custom Installation]** to set another folder.
4. On game selection page of **XXMI Launcher** window click Wuthering Waves tile to add WWMI icon to the top-left corner.
5. Click WWMI icon to open WWMI launcher page and press **[Install]** button to download and install WWMI.

## Known Issues

- Glitch with duplicate modded objects on screen (Merged Skeleton hard limitation, won't be fixed)

## Mod Installation

1. [Extract](https://support.microsoft.com/en-us/windows/zip-and-unzip-files-f6dde0a7-0fec-8294-e1d3-703ed85e7ebc) mod's archive
2. Put extracted folder into the **Mods** folder

## Mod Hot Load

To properly load newly installed mod without restarting the game:
1. Install mod
2. Hide modded character from screen (switch to another)
3. Press **[F10]** to reload WWMI

## Mod User Hotkeys

- **[F12]**: Toggle User Guide
- **[F6]**: Toggle WWMI dependant mods
- **[F10]**: Reload WWMI and Save Mod Settings
- **[Alt]+[F12]**: Toggle 0.6.X Compatibility Mode
- **[Ctrl]+[Alt]+[F10]**: Reset Mod Settings and Reload

## Mod Development
To get into mod creation refer to the **WWMI Tools** and its [Modder Guide](https://github.com/SpectrumQT/WWMI-TOOLS/blob/main/guides/modder_guide.md):
1. [GitHub](https://github.com/SpectrumQT/WWMI-Tools)
2. [Gamebanana](https://gamebanana.com/tools/17289)

## Mod Developer Hotkeys

- **[F9]**: Disable WWMI while held
- **[Ctrl]+[F9]**: Toggle Perfomance Monitor
- **[Ctrl]+[F12]**: Toggle Hunting Mode Guide
- **Numpad [0]**: Toggle Hunting Mode (green text, make sure to **Enable Hunting** in **XXMI Launcher > Settings > WWMI** )

## Resources

- [WWMI GitHub (you're here)] ([Mirror: Gamebanana](https://gamebanana.com/tools/17252))
- [XXMI Launcher GitHub](https://github.com/SpectrumQT/XXMI-Launcher)
- [WWMI Tools GitHub](https://github.com/SpectrumQT/WWMI-Tools) ([Mirror: Gamebanana](https://gamebanana.com/tools/17289))
- [WWMI Assets](https://github.com/SpectrumQT/WWMI-Assets)
- [Wuthering Waves Mods - Gamebanana](https://gamebanana.com/games/20357)
- [Discord Modding Community](https://discord.com/invite/agmg)

## Credits

- Chiri, [Bo3b](https://github.com/bo3b), [DarkStarSword](https://github.com/DarkStarSword) - creators of original 3dmigoto, huge thanks to those guys!
- [SilentNightSound](https://gamebanana.com/members/2176153) - custom 3dmigoto fork, initial WuWa research, AGMG legend (ary Sucrose enjoyer)
- [SpectrumQT](https://gamebanana.com/members/2837527), [SinsOfSeven](https://gamebanana.com/members/2823441) - WWMI Development
- [Leotorrez](https://gamebanana.com/members/2419201), [Petrascyll](https://gamebanana.com/members/2644630), [Zlevir](https://gamebanana.com/members/2694449), [Caverabbit](https://gamebanana.com/members/2987570) - WWMI Contribution

## License

WWMI is licensed under the [GPLv3 License](https://github.com/SpectrumQT/WWMI/blob/main/LICENSE).
